<?php
//define("servcheck",true);
if (defined('servcheck')) {
    $server = "localhost";
    $user = "root";
    $pass = "";
    $dBName = "teambuilder";
}
